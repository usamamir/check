(function () {
  var moneyFormat = (window.Jettribe && window.Jettribe.moneyFormat) || "${{amount}}";

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function formatMoney(cents) {
    var amount = (cents / 100).toFixed(2);
    return String(moneyFormat)
      .replace(/\{\{\s*amount\s*\}\}/, amount)
      .replace(/\{\{\s*amount_no_decimals\s*\}\}/, String(Math.round(cents / 100)))
      .replace(/\{\{\s*amount_with_comma_separator\s*\}\}/, amount.replace(".", ","))
      .replace(/\{\{\s*amount_no_decimals_with_comma_separator\s*\}\}/, String(Math.round(cents / 100)));
  }

  function fetchJSON(url, options) {
    return fetch(url, options).then(function (res) {
      return res.json().then(function (data) {
        if (!res.ok) {
          var message = (data && (data.description || data.message)) || "Something went wrong.";
          throw new Error(message);
        }
        return data;
      });
    });
  }

  function setCartCount(count) {
    qsa("[data-cart-count]").forEach(function (el) { el.textContent = count; });
  }

  var swatchColors = [
    ["black", "#161616"],
    ["navy", "#1e3a8a"],
    ["blue", "#1d4ed8"],
    ["teal", "#0f766e"],
    ["aqua", "#3ec6d4"],
    ["green", "#2f8f4e"],
    ["pink", "#e56aa0"],
    ["magenta", "#e56aa0"],
    ["fuchsia", "#e56aa0"],
    ["grey", "#8a8a8a"],
    ["gray", "#8a8a8a"],
    ["orange", "#f97316"],
    ["purple", "#7c3aed"],
    ["yellow", "#eab308"],
    ["white", "#f7f7f7"],
    ["red", "#e53d42"]
  ];
  function swatchBackground(label) {
    var key = String(label || "").toLowerCase();
    var hits = [];
    swatchColors.forEach(function (row) {
      if (key.indexOf(row[0]) !== -1 && hits.indexOf(row[1]) === -1) hits.push(row[1]);
    });
    if (!hits.length) return "#c8c8c8";
    if (hits.length === 1) return hits[0];
    return "linear-gradient(135deg, " + hits[0] + " 50%, " + hits[1] + " 50%)";
  }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }

  /* Mobile nav */
  var menuToggle = qs("[data-menu-toggle]");
  var siteNav = qs("[data-site-nav]");
  if (menuToggle && siteNav) {
    menuToggle.addEventListener("click", function () {
      var open = siteNav.classList.toggle("is-open");
      menuToggle.setAttribute("aria-expanded", open ? "true" : "false");
      document.body.style.overflow = open ? "hidden" : "";
    });
  }

  /* Mega menu: hover on desktop, click/tap to open panels everywhere. */
  function bindMenuIntent(nav) {
    if (!nav) return;
    var timer = null;
    function closeOthers(except) {
      qsa(".nav-list > .nav-item.is-mega, .nav-list > .nav-item.is-open", nav).forEach(function (other) {
        if (other !== except) {
          other.classList.remove("is-mega");
          other.classList.remove("is-open");
        }
      });
    }
    qsa(".nav-list > .nav-item", nav).forEach(function (item) {
      var hasPanel = !!(qs(".nav-sub, .nav-drop", item));
      item.addEventListener("mouseenter", function () {
        clearTimeout(timer);
        closeOthers(item);
        if (hasPanel) item.classList.add("is-mega");
      });
      item.addEventListener("mouseleave", function () {
        timer = setTimeout(function () {
          item.classList.remove("is-mega");
          item.classList.remove("is-open");
        }, 280);
      });
      if (!hasPanel) return;
      var topLink = item.firstElementChild;
      if (!topLink || String(topLink.tagName || "").toLowerCase() !== "a") {
        topLink = item.querySelector("a");
      }
      if (!topLink) return;
      topLink.addEventListener("click", function (event) {
        var touchish = window.matchMedia("(hover: none), (pointer: coarse)").matches
          || window.matchMedia("(max-width: 991px)").matches;
        if (!touchish) return;
        if (!item.classList.contains("is-mega") && !item.classList.contains("is-open")) {
          event.preventDefault();
          closeOthers(item);
          item.classList.add("is-mega");
          item.classList.add("is-open");
        }
      });
    });
    document.addEventListener("click", function (event) {
      if (!nav.contains(event.target)) {
        qsa(".nav-list > .nav-item.is-mega, .nav-list > .nav-item.is-open", nav).forEach(function (item) {
          item.classList.remove("is-mega");
          item.classList.remove("is-open");
        });
      }
    });
  }
  bindMenuIntent(siteNav);

  qsa(".search-form--split").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      var dept = qs("[data-search-dept]", form);
      var field = qs("input[name='q']", form);
      if (!dept || !dept.value) return;
      if (field && field.value.trim()) return;
      event.preventDefault();
      window.location.href = dept.value;
    });
  });

  /* Sliders */
  function setupSlider(root) {
    if (!root) return;
    var slides = qsa("[data-slide]", root);
    if (!slides.length) return;
    var dotsWrap = qs("[data-dots]", root);
    var index = 0;
    var timer;

    function show(next) {
      index = (next + slides.length) % slides.length;
      slides.forEach(function (slide, i) { slide.classList.toggle("is-active", i === index); });
      if (dotsWrap) {
        qsa("button", dotsWrap).forEach(function (dot, i) { dot.classList.toggle("is-active", i === index); });
      }
    }

    slides.forEach(function (_, i) {
      if (!dotsWrap) return;
      var dot = document.createElement("button");
      dot.type = "button";
      dot.setAttribute("aria-label", "Slide " + (i + 1));
      dot.addEventListener("click", function () { show(i); restart(); });
      dotsWrap.appendChild(dot);
    });

    var prev = qs("[data-prev]", root);
    var next = qs("[data-next]", root);
    if (prev) prev.addEventListener("click", function () { show(index - 1); restart(); });
    if (next) next.addEventListener("click", function () { show(index + 1); restart(); });

    function restart() {
      if (!root.hasAttribute("data-autoplay")) return;
      clearInterval(timer);
      timer = setInterval(function () { show(index + 1); }, 4000);
    }
    show(0);
    restart();
  }
  qsa("[data-slider]").forEach(setupSlider);

  /* Predictive search */
  qsa("[data-predictive]").forEach(function (input) {
    var form = input.closest("form");
    var box = qs("[data-predictive-results]", form);
    var timer;
    if (!box) return;
    input.addEventListener("input", function () {
      clearTimeout(timer);
      var term = input.value.trim();
      if (term.length < 2) { box.hidden = true; box.innerHTML = ""; return; }
      timer = setTimeout(function () {
        var url = "/search/suggest?q=" + encodeURIComponent(term) +
          "&section_id=predictive-search&resources[type]=product,page,article&resources[limit]=6";
        fetch(url).then(function (res) { return res.text(); }).then(function (html) {
          var doc = new DOMParser().parseFromString(html, "text/html");
          var inner = doc.querySelector(".predictive") || doc.body;
          box.innerHTML = inner.innerHTML;
          if (window.JettribeSku) JettribeSku.fillPredictive(box, term);
          box.hidden = !box.innerHTML.trim();
        }).catch(function () { box.hidden = true; });
      }, 220);
    });
    document.addEventListener("click", function (event) {
      if (!form.contains(event.target)) box.hidden = true;
    });
  });

  /* Cart drawer */
  var cartDrawer = qs("[data-cart-drawer]");
  var cartBackdrop = qs("[data-cart-backdrop]");

  function openCart() {
    if (!cartDrawer) return;
    cartDrawer.hidden = false;
    if (cartBackdrop) cartBackdrop.hidden = false;
    document.body.style.overflow = "hidden";
  }
  function closeCart() {
    if (!cartDrawer) return;
    cartDrawer.hidden = true;
    if (cartBackdrop) cartBackdrop.hidden = true;
    if (!(siteNav && siteNav.classList.contains("is-open"))) document.body.style.overflow = "";
  }
  qsa("[data-open-cart]").forEach(function (el) {
    el.addEventListener("click", function (event) {
      if (window.Jettribe && window.Jettribe.cartType === "page") return;
      event.preventDefault();
      renderCart().then(openCart);
    });
  });
  qsa("[data-close-cart]").forEach(function (el) { el.addEventListener("click", closeCart); });

  function renderCart() {
    return fetchJSON("/cart.js").then(function (cart) {
      setCartCount(cart.item_count);
      var body = qs("[data-cart-body]");
      var foot = qs("[data-cart-foot]");
      if (!body) return;
      if (!cart.items.length) {
        body.innerHTML = "<p>Your cart is empty.</p>";
        if (foot) foot.hidden = true;
        return;
      }
      body.innerHTML = cart.items.map(function (item) {
        var opts = (item.options_with_values || []).filter(function (o) { return o.value !== "Default Title"; })
          .map(function (o) { return "<div>" + o.name + ": " + o.value + "</div>"; }).join("");
        return '<article class="drawer-line">' +
          '<a href="' + item.url + '"><img src="' + (item.image || "") + '" alt=""></a>' +
          "<div><a href=\"" + item.url + "\">" + item.product_title + "</a>" +
          opts +
          "<div>" + formatMoney(item.final_line_price) + "</div>" +
          '<label class="visually-hidden" for="qty-' + item.key + '">Quantity</label>' +
          '<input class="input" style="width:72px;margin-top:6px" id="qty-' + item.key + '" type="number" min="0" value="' + item.quantity + '" data-line-key="' + item.key + '">' +
          '<button type="button" class="remove-link" data-remove-key="' + item.key + '">Remove</button>' +
          "</div></article>";
      }).join("");
      if (foot) {
        foot.hidden = false;
        var total = qs("[data-cart-total]");
        if (total) total.textContent = formatMoney(cart.total_price);
        var ship = qs("[data-ship-message]");
        var threshold = (window.Jettribe && window.Jettribe.freeShipping) || 0;
        if (ship && threshold > 0) {
          if (cart.total_price >= threshold) ship.textContent = "This order qualifies for free USA shipping.";
          else ship.textContent = "Add " + formatMoney(threshold - cart.total_price) + " more for free USA shipping.";
        }
      }
    });
  }

  function changeLine(key, quantity) {
    return fetchJSON("/cart/change.js", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ id: key, quantity: quantity })
    }).then(function () { return renderCart(); });
  }

  document.addEventListener("change", function (event) {
    var input = event.target.closest("[data-line-key]");
    if (!input) return;
    changeLine(input.getAttribute("data-line-key"), Number(input.value || 0)).catch(function (err) { alert(err.message); });
  });
  document.addEventListener("click", function (event) {
    var btn = event.target.closest("[data-remove-key]");
    if (!btn) return;
    changeLine(btn.getAttribute("data-remove-key"), 0).catch(function (err) { alert(err.message); });
  });

  function addItem(id, quantity, properties) {
    var payload = { id: Number(id), quantity: Number(quantity || 1) };
    if (properties && Object.keys(properties).length) payload.properties = properties;
    return fetchJSON("/cart/add.js", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(payload)
    });
  }

  document.addEventListener("click", function (event) {
    var add = event.target.closest("[data-add-variant]");
    if (!add) return;
    event.preventDefault();
    add.disabled = true;
    addItem(add.getAttribute("data-add-variant"), 1).then(function () {
      return renderCart();
    }).then(openCart).catch(function (err) {
      alert(err.message);
    }).finally(function () { add.disabled = false; });
  });

  document.addEventListener("submit", function (event) {
    var form = event.target;
    if (!form.matches("[data-product-form]")) return;
    var submitter = event.submitter;
    if (!submitter || !submitter.hasAttribute("data-add-button")) return;
    var data = new FormData(form);
    var hasFile = false;
    data.forEach(function (value) {
      if (typeof File !== "undefined" && value instanceof File && value.size > 0) hasFile = true;
    });
    if (hasFile) return;
    event.preventDefault();
    var properties = {};
    data.forEach(function (value, key) {
      if (key.indexOf("properties[") === 0 && String(value).trim() && !(value instanceof File)) {
        properties[key.slice(11, -1)] = value;
      }
    });
    var button = qs("[data-add-button]", form);
    if (button) button.disabled = true;
    addItem(data.get("id"), data.get("quantity") || 1, properties).then(function () {
      return renderCart();
    }).then(function () {
      var modal = qs("[data-quick-modal]");
      if (modal) modal.hidden = true;
      var backdrop = qs("[data-modal-backdrop]");
      if (backdrop) backdrop.hidden = true;
      openCart();
    }).catch(function (err) {
      var box = qs("[data-product-error]", form) || qs("[data-quick-error]");
      if (box) { box.hidden = false; box.textContent = err.message; }
      else alert(err.message);
    }).finally(function () { if (button) button.disabled = false; });
  });

  /* Normalize BigCommerce-style size + name-plate options for product forms */
  function parseMangledOption(raw) {
    var value = String(raw == null ? "" : raw).trim();
    if (!value) return null;
    if (/\[PI\]|Name Plate=|Font Customization/i.test(value)) {
      var sizePart = value.split(/,\[PI\]/)[0].replace(/^Size=/i, "").trim();
      sizePart = canonicalSize(sizePart) || sizePart.replace(/\s*\/\s*/g, "/").replace(/\s+/g, " ").trim();
      var plate = "None";
      var m = value.match(/=\s*([^,:]+)(?::\d+)?\s*$/);
      if (m) {
        var choice = m[1].trim();
        if (/moto/i.test(choice)) plate = "Moto Font Customization";
        else if (/standard/i.test(choice)) plate = "Standard Font Customization";
        else if (/blank/i.test(choice)) plate = "Blank PVC Vest Name Plate ($25)";
        else if (/custom pvc/i.test(choice)) plate = "Custom PVC Vest Name Plate ($60)";
        else if (/yes custom/i.test(choice)) plate = "Yes Customization";
        else if (!/^none$/i.test(choice)) plate = choice;
      }
      return { size: sizePart, plate: plate, mangled: true };
    }
    var clean = canonicalSize(value);
    if (clean) return { size: clean, plate: "None", mangled: false };
    if (/^(none|default)$/i.test(value)) return { size: "", plate: "None", mangled: false };
    if (/moto font/i.test(value)) return { size: "", plate: "Moto Font Customization", mangled: false };
    if (/standard font/i.test(value)) return { size: "", plate: "Standard Font Customization", mangled: false };
    return { size: value.replace(/\s*\/\s*/g, "/"), plate: "", mangled: false };
  }

  function displayPlateLabel(value) {
    var v = String(value || "").trim();
    if (!v || /^(none|default)$/i.test(v)) return "None";
    if (/custom pvc/i.test(v)) return "Custom PVC Vest Name Plate ($60)";
    if (/blank pvc/i.test(v)) return "Blank PVC Vest Name Plate ($25)";
    if (/yes custom/i.test(v)) return "Yes Customization";
    if (/moto/i.test(v) && !/moto font customization/i.test(v)) return "Moto Font Customization";
    if (/standard/i.test(v) && !/standard font customization/i.test(v)) return "Standard Font Customization";
    return v;
  }

  function productTags(prod) {
    if (!prod) return [];
    if (Array.isArray(prod.tags)) return prod.tags.map(function (tag) { return String(tag || "").trim(); });
    return String(prod.tags || "").split(",").map(function (tag) { return tag.trim(); }).filter(Boolean);
  }

  function isPvcProduct(prod) {
    var blob = ((prod.options || []).map(optionLabel).join(" ") + " " +
      (prod.variants || []).map(function (variant) { return (variant.options || []).join(" "); }).join(" ") + " " +
      productTags(prod).join(" ")).toLowerCase();
    return /pvc/.test(blob) || /pvc-plate-custom/.test(blob) || /blank \$25|custom \$60/.test(blob);
  }

  function isFortyPlateProduct(prod) {
    if (isPvcProduct(prod)) return false;
    var blob = ((prod.options || []).map(optionLabel).join(" ") + " " +
      (prod.variants || []).map(function (variant) { return (variant.options || []).join(" "); }).join(" ") + " " +
      productTags(prod).join(" ")).toLowerCase();
    return /\$40|customized vest name plate|moto font|standard font|yes customization|letter-choice:a-v|custom-plate:yes-av/.test(blob);
  }

  function isYesAvProduct(prod) {
    if (isPvcProduct(prod)) return false;
    var tags = productTags(prod).join(" ").toLowerCase();
    if (/letter-choice:a-v|custom-plate:yes-av/.test(tags)) return true;
    var blob = ((prod.options || []).map(optionLabel).join(" ") + " " +
      (prod.variants || []).map(function (variant) { return (variant.options || []).join(" "); }).join(" ")).toLowerCase();
    return /yes customization/.test(blob);
  }

  function letterChoiceRange(prod) {
    var el = qs("[data-letter-choice-range]");
    if (el) {
      var fromDom = String(el.getAttribute("data-letter-choice-range") || "").trim();
      if (fromDom) return fromDom;
    }
    var tag = productTags(prod).filter(function (item) { return item.indexOf("letter-choice:") === 0; })[0];
    if (tag === "letter-choice:A-V" || (prod && prod._jtYesAv)) return "A-V";
    if (tag === "letter-choice:A-R" || (prod && prod._jtPvc)) return "A-R";
    if (tag && tag.indexOf("letter-choice:") === 0) return tag.slice(13);
    if (prod && prod._jtYesAv) return "A-V";
    if (prod && prod._jtPvc) return "A-R";
    return "";
  }

  function lettersForRange(range) {
    // BC Yes Customization skips letter R (A–Q, S–V)
    if (range === "A-V") return "ABCDEFGHIJKLMNOPQSTUV".split("");
    if (range === "A-R") return "ABCDEFGHIJKLMNOPQR".split("");
    if (range && range.indexOf(",") !== -1) return range.split(",").map(function (item) { return item.trim(); }).filter(Boolean);
    return "ABCDEFGHIJKLMNOPQR".split("");
  }

  function plateOptionTitle(name, prod) {
    var n = String(name || "");
    if (isPvcProduct(prod) || /pvc/i.test(n)) return "Add-on PVC Plate: Blank $25 | Custom $60";
    if (/name\s*plate|customized vest name plate|\$40/i.test(n)) return "$40 - Add Customized Vest Name Plate";
    return n;
  }

  function rematerializeProduct(prod) {
    if (!prod || !prod.variants || !prod.variants.length) return prod;
    var mangledCount = 0;
    prod.variants.forEach(function (variant) {
      (variant.options || []).forEach(function (opt) {
        if (/\[PI\]|Name Plate=|Font Customization:\d+|PVC Vest Name Plate/i.test(String(opt || ""))) mangledCount += 1;
      });
    });
    var optionNames = (prod.options || []).map(optionLabel);
    var pvc = isPvcProduct(prod);
    var yesAv = isYesAvProduct(prod);
    var forty = isFortyPlateProduct(prod) || yesAv;
    var hasPlateOption = optionNames.some(function (name) {
      return /plate|font|custom|pvc/i.test(name) && !/^size$/i.test(name);
    });
    var letterIndex = -1;
    optionNames.forEach(function (name, index) {
      if (/design confirmation|letter|select letter/i.test(name) && !/plate/i.test(name)) letterIndex = index;
    });

    if ((pvc || forty || mangledCount) && (hasPlateOption || mangledCount)) {
      var sizeIndex = optionNames.findIndex(function (name) { return /size/i.test(name); });
      var plateIndex = optionNames.findIndex(function (name) {
        return /plate|pvc|font|\$40|\$25|\$60/i.test(name) && !/design confirmation|letter/i.test(name);
      });
      if (mangledCount && sizeIndex === -1) sizeIndex = 0;
      if (mangledCount && plateIndex === -1) plateIndex = 0;

      var grouped = {};
      prod.variants.forEach(function (variant) {
        var opts = variant.options || [];
        var size = "One Size";
        var plate = "None";
        if (mangledCount && opts[0] && /\[PI\]|PVC Vest Name Plate|Font Customization/i.test(String(opts[0]))) {
          var parsed = parseMangledOption(opts[0]) || {};
          size = parsed.size || size;
          plate = displayPlateLabel(parsed.plate || "None");
        } else {
          if (sizeIndex >= 0) size = canonicalSize(opts[sizeIndex]) || String(opts[sizeIndex] || "").replace(/\s*\/\s*/g, "/") || size;
          if (plateIndex >= 0) plate = displayPlateLabel(opts[plateIndex] || "None");
          // letter-only / plate-as-option1 rows
          if (plateIndex === 0 && /pvc|plate|none|custom|blank/i.test(String(opts[0] || ""))) {
            plate = displayPlateLabel(opts[0]);
            if (sizeIndex < 0) size = "One Size";
          }
        }
        if (/^[A-R]$/i.test(size) && pvc) {
          // letter was mistaken for size
          size = "One Size";
        }
        var key = size + "||" + plate;
        if (!grouped[key] || (variant.available && !grouped[key].available) || variant.price < grouped[key].price) {
          var copy = Object.assign({}, variant);
          copy.options = [size, plate];
          copy.option1 = size;
          copy.option2 = plate;
          copy.option3 = null;
          grouped[key] = copy;
        }
      });
      prod.variants = Object.keys(grouped).map(function (key) { return grouped[key]; });
      prod.options = [
        "Size",
        pvc ? "Add-on PVC Plate: Blank $25 | Custom $60" : "$40 - Add Customized Vest Name Plate"
      ];
      prod._jtPvc = pvc;
      prod._jtYesAv = !pvc && yesAv;
      prod._jtForty = !pvc && forty;
      return prod;
    }

    if (!mangledCount && hasPlateOption) {
      prod.options = optionNames.map(function (name) {
        if (/size/i.test(name)) return "Size";
        if (/design confirmation|letter/i.test(name)) return name;
        if (/plate|font|pvc/i.test(name)) return plateOptionTitle(name, prod);
        return name;
      });
      prod.variants.forEach(function (variant) {
        variant.options = (variant.options || []).map(function (opt, index) {
          var name = String(prod.options[index] || "");
          if (/size/i.test(name)) return canonicalSize(opt) || String(opt || "").replace(/\s*\/\s*/g, "/");
          if (/plate|pvc/i.test(name)) return displayPlateLabel(opt);
          return opt;
        });
        variant.option1 = variant.options[0];
        variant.option2 = variant.options[1];
        variant.option3 = variant.options[2];
      });
      prod._jtPvc = pvc;
      prod._jtYesAv = !pvc && yesAv;
      prod._jtForty = !pvc && forty;
      return prod;
    }
    prod._jtPvc = pvc;
    prod._jtYesAv = !pvc && yesAv;
    prod._jtForty = !pvc && forty;
    return prod;
  }

  function renderOptionGroups(form, prod, namePrefix) {
    var mount = qs("[data-option-mount]", form);
    if (mount) {
      mount.innerHTML = "";
    } else {
      qsa("[data-option-index]", form).forEach(function (el) {
        var label = el.previousElementSibling;
        if (label && label.classList.contains("option-label")) label.remove();
        el.remove();
      });
      qsa("[data-addon-note]", form).forEach(function (el) { el.remove(); });
    }
    var html = "";
    (prod.options || []).forEach(function (name, index) {
      var seen = {};
      var values = [];
      (prod.variants || []).forEach(function (variant) {
        var value = (variant.options || [])[index];
        if (value == null || value === "" || seen[value]) return;
        seen[value] = true;
        values.push(value);
      });
      if (!values.length) return;
      if (/plate/i.test(String(name))) {
        values.sort(function (a, b) {
          if (/^none$/i.test(a)) return -1;
          if (/^none$/i.test(b)) return 1;
          return a.localeCompare(b);
        });
      }
      html += '<div class="option-label">' + escapeHtml(name) + "</div>";
      html += '<div class="option-values" data-option-index="' + index + '" data-option-name="' + escapeHtml(name) + '"' + (/plate|pvc/i.test(String(name)) ? ' data-plate-group="true"' : "") + ">";
      values.forEach(function (value, valueIndex) {
        var checked = false;
        if (/plate|pvc/i.test(String(name))) checked = /^none$/i.test(value);
        else checked = !valueIndex && !values.some(function (item) { return /^none$/i.test(item); });
        if (/plate|pvc/i.test(String(name)) && !values.some(function (item) { return /^none$/i.test(item); })) checked = !valueIndex;
        html += '<label class="' + (checked ? "is-selected" : "") + '"><input type="radio" name="' + namePrefix + "-" + index + '" value="' + escapeHtml(value) + '" data-option-input' + (checked ? " checked" : "") + "><span>" + escapeHtml(value) + "</span></label>";
      });
      html += "</div>";
      if (/plate|pvc/i.test(String(name))) {
        var note = prod && prod._jtPvc
          ? "Choose None for the vest only. Custom ($60) unlocks plate designs A–R plus name/number. Blank ($25) adds an unprinted plate."
          : (prod && prod._jtYesAv)
            ? "Choose None for the vest only. Yes Customization (+$40) unlocks Design Confirmation A–V plus name/number. Custom plates take 1–2 weeks and ship separately."
            : "Choose None if you do not want a customized name plate. Custom plates take an extra 1–2 weeks and ship separately.";
        html += '<p class="addon-note" data-addon-note>' + note + "</p>";
      }
    });
    if (mount) mount.innerHTML = html;
    else {
      var anchor = qs("[data-option-anchor]", form) || qs(".qty-row", form) || qs("[data-add-button]", form);
      if (anchor) {
        var wrap = document.createElement("div");
        wrap.setAttribute("data-option-mount", "");
        wrap.innerHTML = html;
        anchor.parentNode.insertBefore(wrap, anchor);
      }
    }
    ensurePlateTextFields(form, prod);
    ensureLetterUI(form, prod);
    syncPlateCustomization(form, prod);
  }

  function ensurePlateTextFields(form, prod) {
    if (qs("[data-plate-fields]", form)) return;
    var pvc = !!(prod && prod._jtPvc) || isPvcProduct(prod || {});
    var yesAv = !!(prod && prod._jtYesAv) || isYesAvProduct(prod || {});
    var existing = [];
    qsa(".field", form).forEach(function (field) {
      var input = qs("input[type='text'], textarea", field);
      if (!input || !input.name) return;
      if (/name for plate|plate personalization|race number|custom name|custom number/i.test(input.name + " " + (qs("label", field) || {}).textContent)) {
        existing.push(field);
      }
    });
    var box = document.createElement("div");
    box.setAttribute("data-plate-fields", "");
    box.hidden = true;
    if (existing.length) {
      existing.forEach(function (field) { box.appendChild(field); });
    } else if (pvc) {
      box.innerHTML =
        '<div class="field"><label for="CustomName60">Enter Custom Name (Only with $60 Custom Option)</label>' +
        '<input class="input" id="CustomName60" type="text" name="properties[Enter Custom Name (Only with $60 Custom Option)]"></div>' +
        '<div class="field"><label for="CustomNumber60">Enter Custom Number (Only with $60 Custom Option)</label>' +
        '<input class="input" id="CustomNumber60" type="text" name="properties[Enter Custom Number (Only with $60 Custom Option)]"></div>';
    } else if (yesAv) {
      box.innerHTML =
        '<div class="field"><label for="PlatePersonalizationName">Plate Personalization Name (Only if $40 Option Added)</label>' +
        '<input class="input" id="PlatePersonalizationName" type="text" name="properties[Plate Personalization Name (Only if $40 Option Added)]"></div>' +
        '<div class="field"><label for="RaceNumber40">Race Number (Only if $40 Option Added)</label>' +
        '<input class="input" id="RaceNumber40" type="text" name="properties[Race Number (Only if $40 Option Added)]"></div>';
    } else {
      box.innerHTML =
        '<div class="field"><label for="NameForPlate">Name for Plate (Only if $40 Option Added)</label>' +
        '<input class="input" id="NameForPlate" type="text" name="properties[Name for Plate (Only if $40 Option Added)]"></div>' +
        '<div class="field"><label for="RaceNumberPlate">Race Number (Only if Custom Option is Added)</label>' +
        '<input class="input" id="RaceNumberPlate" type="text" name="properties[Race Number (Only if Custom Option is Added)]"></div>';
    }
    var note = qs("[data-addon-note]", form);
    var anchor = note || qs("[data-option-anchor]", form) || qs(".qty-row", form) || qs("[data-add-button]", form);
    if (anchor) anchor.parentNode.insertBefore(box, note ? note.nextSibling : anchor);
    else form.appendChild(box);
  }

  function ensureLetterUI(form, prod) {
    var pvc = !!(prod && prod._jtPvc) || isPvcProduct(prod || {});
    var yesAv = !!(prod && prod._jtYesAv) || isYesAvProduct(prod || {});
    if (!pvc && !yesAv) return;
    if (qs("[data-pvc-letter-wrap]", form)) return;
    var range = letterChoiceRange(prod) || (yesAv ? "A-V" : "A-R");
    var letters = lettersForRange(range);
    var label = range === "A-V"
      ? "Design Confirmation (Select Letter A–V)"
      : "Design Confirmation (Select Letter A–R)";
    var wrap = document.createElement("div");
    wrap.setAttribute("data-pvc-letter-wrap", "");
    wrap.hidden = true;
    wrap.innerHTML =
      '<div class="option-label">' + label + "</div>" +
      '<div class="option-values" data-pvc-letters>' +
      letters.map(function (letter, index) {
        return '<label class="' + (!index ? "is-selected" : "") + '"><input type="radio" name="properties[' + label + ']" value="' +
          letter + '" data-pvc-letter' + (!index ? " checked" : "") + "><span>" + letter + "</span></label>";
      }).join("") +
      "</div>" +
      '<p class="addon-note">Pick a plate design. The main image updates to that letter layout.</p>';
    var plateGroup = qs("[data-plate-group]", form);
    var insertAfter = plateGroup || qs("[data-addon-note]", form) || qs("[data-option-mount]", form);
    if (insertAfter) insertAfter.parentNode.insertBefore(wrap, insertAfter.nextSibling);
    else form.appendChild(wrap);
  }

  function ensurePvcLetterUI(form, prod) {
    ensureLetterUI(form, prod);
  }

  var plateDesignCache = null;
  function loadPlateDesigns() {
    if (plateDesignCache) return Promise.resolve(plateDesignCache);
    var src = (window.Jettribe && Jettribe.plateDesignsUrl) || "";
    var el = qs("[data-plate-designs-url]");
    if (el) src = el.getAttribute("data-plate-designs-url") || src;
    if (!src) {
      plateDesignCache = {};
      return Promise.resolve(plateDesignCache);
    }
    return fetch(src).then(function (res) {
      if (!res.ok) throw new Error("plate designs");
      return res.json();
    }).then(function (json) {
      plateDesignCache = json || {};
      return plateDesignCache;
    }).catch(function () {
      plateDesignCache = {};
      return plateDesignCache;
    });
  }

  function selectedPvcPlate(form) {
    var group = qs("[data-plate-group]", form);
    var checked = group ? qs("input:checked", group) : null;
    return checked ? String(checked.value || "") : "";
  }

  function selectedPvcLetter(form) {
    var checked = qs("[data-pvc-letter]:checked", form);
    return checked ? String(checked.value || "").toUpperCase() : "";
  }

  function syncPlateCustomization(form, prod) {
    if (!form) return;
    var pvc = !!(prod && prod._jtPvc) || isPvcProduct(prod || {});
    var yesAv = !!(prod && prod._jtYesAv) || isYesAvProduct(prod || {});
    var plate = selectedPvcPlate(form);
    var isCustomPvc = /custom pvc/i.test(plate);
    var isYes = /yes custom/i.test(plate);
    var showLetters = (pvc && isCustomPvc) || (yesAv && isYes);
    var letterWrap = qs("[data-pvc-letter-wrap]", form);
    var fields = qs("[data-plate-fields]", form);
    if (letterWrap) {
      letterWrap.hidden = !showLetters;
      qsa("[data-pvc-letter]", letterWrap).forEach(function (input) {
        input.disabled = !showLetters;
      });
    }
    if (fields) {
      // PVC: only Custom $60; Yes A-V: Yes Customization; Moto/Standard: any non-None
      var on = pvc ? isCustomPvc : !!(plate && !/^none$/i.test(plate));
      fields.hidden = !on;
      qsa("input, textarea", fields).forEach(function (input) {
        input.disabled = !on;
        if (!on) input.value = "";
      });
    }
    var main = qs("[data-gallery-main]");
    if (!main) return;
    if (!form._jtDefaultImage) form._jtDefaultImage = main.getAttribute("src") || "";
    if (!showLetters) {
      if (form._jtDefaultImage) main.src = form._jtDefaultImage;
      return;
    }
    var letter = selectedPvcLetter(form);
    if (!letter) return;
    loadPlateDesigns().then(function (map) {
      var handle = (prod && prod.handle) || "";
      var row = map[handle] || {};
      var url = (row.designs && row.designs[letter]) || "";
      if (url) main.src = url;
    });
  }

  function syncPvcCustomization(form, prod) {
    syncPlateCustomization(form, prod);
  }

  function syncPlateTextFields(form, prod) {
    syncPlateCustomization(form, prod);
  }

  /* Product page variants */
  var productJsonEl = qs("[data-product-json]");
  if (productJsonEl) {
    var product = rematerializeProduct(JSON.parse(productJsonEl.textContent));
    var form = qs("[data-product-form]");
    var idInput = qs("[data-variant-id]", form);
    var priceEl = qs("[data-product-price]");
    var skuEl = qs("[data-sku]");
    var button = qs("[data-add-button]", form);

    if (form) {
      if (!qs("[data-option-anchor]", form)) {
        var qty = qs(".qty-row", form);
        if (qty) qty.setAttribute("data-option-anchor", "");
      }
      var needsRebuild = (product.options || []).some(function (name) {
        return /plate|font/i.test(String(name));
      }) || (product.variants || []).some(function (variant) {
        return (variant.options || []).some(function (opt) {
          return /\[PI\]|Name Plate=|Font Customization:\d+/i.test(String(opt || ""));
        });
      });
      if (needsRebuild || product._jtPvc || product._jtForty || product._jtYesAv) renderOptionGroups(form, product, "option");
      else {
        ensurePlateTextFields(form, product);
        qsa("[data-option-index]", form).forEach(function (group) {
          if (/plate|pvc|yes custom/i.test(group.getAttribute("data-option-name") || "")) {
            group.setAttribute("data-plate-group", "true");
          }
        });
        ensureLetterUI(form, product);
        syncPlateCustomization(form, product);
      }
      var mount = qs("[data-option-mount]", form);
      if (mount) mount.setAttribute("data-ready", "");
    }

    function selectedOptions() {
      return qsa("[data-option-index]", form).map(function (group) {
        var checked = qs("input:checked", group);
        return checked ? checked.value : "";
      });
    }

    function findVariant(options) {
      var matches = product.variants.filter(function (variant) {
        return variant.options.every(function (opt, i) {
          return !options[i] || opt === options[i];
        });
      });
      matches.sort(function (a, b) { return a.price - b.price; });
      return matches[0];
    }

    function isAddonGroup(group) {
      var name = group.getAttribute("data-option-name") || "";
      if (/design confirmation|letter/i.test(name) && !/plate/i.test(name)) return false;
      if (/plate|pvc/i.test(name)) return true;
      var values = qsa("input", group).map(function (input) { return input.value; }).join(" ");
      var priced = /\$\s*\d/.test(name) || /\$\s*\d/.test(values);
      if (!priced) return false;
      return /add-?on|plate|sock|custom|pvc/i.test(name);
    }

    function markSelected(group) {
      qsa("label", group).forEach(function (label) {
        var input = qs("input", label);
        label.classList.toggle("is-selected", !!(input && input.checked));
      });
    }

    function chooseNone(group) {
      var real = qsa("input", group).filter(function (input) {
        return /^none$/i.test(String(input.value || "").trim());
      })[0];
      if (!real && !qs("input[data-addon-none]", group)) {
        var sample = qs("input", group);
        if (!sample) return;
        var label = document.createElement("label");
        label.innerHTML = '<input type="radio" name="' + sample.name + '" value="None" data-option-input data-addon-none><span>None</span>';
        group.insertBefore(label, group.firstChild);
        real = qs("input[data-addon-none]", group);
      }
      if (!qs("[data-addon-note]", group.parentElement)) {
        var note = document.createElement("p");
        note.className = "addon-note";
        note.setAttribute("data-addon-note", "");
        note.textContent = "Choose None if you do not want this add-on.";
        group.insertAdjacentElement("afterend", note);
      }
      if (!real) return;
      qsa("input", group).forEach(function (input) { input.checked = input === real; });
      markSelected(group);
    }

    function selectedLetter() {
      var field = qs("[data-letter-choice]", form);
      if (field && field.value) return String(field.value).toUpperCase();
      var letter = "";
      qsa("[data-option-index]", form).forEach(function (group) {
        var checked = qs("input:checked", group);
        if (!checked) return;
        var value = String(checked.value || "").trim();
        if (/^[A-Za-z]$/.test(value)) letter = value.toUpperCase();
      });
      return letter;
    }

    function showLetterImage(letter) {
      if (!letter) return;
      var token = new RegExp("(^|[^A-Za-z0-9])" + letter + "([^A-Za-z0-9]|$)", "i");
      var hint = /plate|letter|design|font|custom/i;
      var pool = qsa("[data-thumb]").map(function (thumb) {
        return {
          src: thumb.getAttribute("data-src") || "",
          alt: thumb.getAttribute("data-alt") || "",
          thumb: thumb
        };
      });
      qsa(".product-lower .rte img").forEach(function (img) {
        pool.push({ src: img.getAttribute("src") || "", alt: img.getAttribute("alt") || "", thumb: null });
      });
      var hit = null;
      pool.some(function (item) {
        var hay = item.alt + " " + item.src;
        if (token.test(hay) && hint.test(hay)) {
          hit = item;
          return true;
        }
        return false;
      });
      if (!hit || !hit.src) return;
      var main = qs("[data-gallery-main]");
      if (main) main.src = hit.src;
      qsa("[data-thumb]").forEach(function (el) { el.classList.remove("is-active"); });
      if (hit.thumb) hit.thumb.classList.add("is-active");
    }

    function refreshAvailability() {
      var options = selectedOptions();
      qsa("[data-option-index]", form).forEach(function (group, index) {
        qsa("input", group).forEach(function (input) {
          var trial = options.slice();
          trial[index] = input.value;
          var match = product.variants.some(function (variant) {
            return variant.available && variant.options.every(function (opt, i) {
              return trial[i] === "" || opt === trial[i];
            });
          });
          input.parentElement.classList.toggle("is-unavailable", !match);
        });
      });
    }

    function applyVariant() {
      var variant = findVariant(selectedOptions());
      refreshAvailability();
      syncPlateTextFields(form, product);
      if (!variant) {
        if (button) { button.disabled = true; button.textContent = "Unavailable"; }
        return;
      }
      idInput.value = variant.id;
      if (priceEl) {
        var showPrice = variant.price;
        if (!showPrice || !variant.available) {
          var availablePriced = product.variants.filter(function (item) {
            return item.available && item.price > 0;
          }).sort(function (a, b) { return a.price - b.price; })[0];
          var priced = availablePriced || product.variants.filter(function (item) {
            return item.price > 0;
          }).sort(function (a, b) { return a.price - b.price; })[0];
          if (priced) showPrice = priced.price;
        }
        var html = "";
        if (variant.compare_at_price && variant.compare_at_price > showPrice) {
          html += "<s>" + formatMoney(variant.compare_at_price) + "</s> ";
        }
        html += "Now: " + formatMoney(showPrice);
        priceEl.innerHTML = html;
      }
      var paypalNote = qs("[data-pp-message]");
      if (paypalNote) {
        paypalNote.setAttribute("data-pp-amount", (variant.price / 100).toFixed(2));
        paypalNote.removeAttribute("data-pp-mounted");
        mountPayPalMessages();
      }
      if (skuEl) {
        var sku = variant.sku || skuEl.getAttribute("data-fallback-sku") || "";
        skuEl.textContent = sku ? "SKU: " + sku : "";
      }
      if (button) {
        button.disabled = !variant.available;
        button.textContent = variant.available ? "Add to Cart" : "Out of Stock";
      }
      if (variant.featured_image) {
        var main = qs("[data-gallery-main]");
        if (main) main.src = variant.featured_image.src;
      }
      showLetterImage(selectedLetter());
      var url = new URL(window.location.href);
      url.searchParams.set("variant", variant.id);
      window.history.replaceState({}, "", url);
    }

    form.addEventListener("change", function (event) {
      if (event.target.matches("[data-option-input], [data-letter-choice], [data-pvc-letter]")) {
        var group = event.target.closest("[data-option-index], [data-pvc-letters]");
        if (group) markSelected(group);
        applyVariant();
        syncPvcCustomization(form, product);
      }
    });
    if (!new URL(window.location.href).searchParams.get("variant")) {
      qsa("[data-option-index]", form).forEach(function (group) {
        if (isAddonGroup(group)) chooseNone(group);
      });
    }
    applyVariant();
    syncPvcCustomization(form, product);

    qsa("[data-thumb]").forEach(function (thumb) {
      thumb.addEventListener("click", function () {
        var main = qs("[data-gallery-main]");
        if (main && thumb.getAttribute("data-src")) main.src = thumb.getAttribute("data-src");
        qsa("[data-thumb]").forEach(function (el) { el.classList.remove("is-active"); });
        thumb.classList.add("is-active");
      });
    });

    qsa("[data-tab]").forEach(function (tab) {
      tab.addEventListener("click", function () {
        qsa("[data-tab]").forEach(function (el) { el.classList.remove("is-active"); });
        qsa("[data-tab-panel]").forEach(function (el) { el.classList.remove("is-active"); });
        tab.classList.add("is-active");
        var panel = qs('[data-tab-panel="' + tab.getAttribute("data-tab") + '"]');
        if (panel) panel.classList.add("is-active");
      });
    });
  }

  function optionLabel(option) {
    if (option && typeof option === "object") return option.name || option.label || "";
    return option == null ? "" : String(option);
  }
  function isNoneValue(value) {
    return /^none$/i.test(String(value || "").trim());
  }
  function isAddonLabel(label, values) {
    if (/design|letter/i.test(label)) return false;
    var blob = label + " " + (values || []).join(" ");
    return /\$\s*\d/.test(blob) && /add-?on|plate|sock|custom/i.test(blob);
  }
  var SIZE_WORD = "(?:XXS|XS|S|M|L|XL|XXL|XXXL|XXXXL|2XL|3XL|4XL|5XL|Small|Medium|Large|X\\s*-?\\s*Large|XX\\s*-?\\s*Large|XXX\\s*-?\\s*Large|Extra\\s*Small|Extra\\s*Large|X\\s*Small)";
  var SIZE_LABEL = new RegExp("^" + SIZE_WORD + "(?:\\s*\\/\\s*" + SIZE_WORD + ")?$", "i");
  var SIZE_NUMERIC = /^(?:[5-9]|1[0-5]|2[8-9]|[3-4][0-9])$/;
  function isSizeJunk(value) {
    return /\[PI\]|name\s*plate|customization|add\s*custom|font\s*custom|\$\s*\d|gift\s*card|restrictions\s*apply/i.test(String(value || ""));
  }
  function mapSizeToken(token) {
    var t = String(token || "").trim().toLowerCase().replace(/-/g, " ");
    t = t.replace(/\s+/g, " ");
    var table = {
      "extra small": "XS", "x small": "XS", xsmall: "XS", xs: "XS",
      xxs: "XXS", "2xs": "XXS", "xx small": "XXS",
      small: "S", s: "S",
      medium: "M", m: "M", med: "M",
      large: "L", l: "L",
      "extra large": "XL", "x large": "XL", xlarge: "XL", xl: "XL",
      "xx large": "XXL", xxlarge: "XXL", xxl: "XXL",
      "2xl": "2XL", "2x": "2XL", "2x large": "2XL",
      "xxx large": "3XL", xxxlarge: "3XL", xxxl: "3XL", "3xl": "3XL", "3x": "3XL",
      "4xl": "4XL", "4x": "4XL", "5xl": "5XL", "5x": "5XL"
    };
    if (table[t]) return table[t];
    var compact = t.replace(/\s+/g, "");
    if (table[compact]) return table[compact];
    var up = String(token || "").trim().toUpperCase().replace(/\s+/g, "");
    if (/^(XXS|XS|S|M|L|XL|XXL|2XL|3XL|4XL|5XL)$/.test(up)) return up === "XXXL" ? "3XL" : up;
    return "";
  }
  function canonicalSize(value) {
    var raw = String(value == null ? "" : value).trim();
    if (!raw || /^default\s*title$/i.test(raw) || /^none$/i.test(raw)) return "";
    var head = raw.split(/,|\[PI\]|\[RB\]|\[S\]|\[RT\]|\[CS\]/)[0].trim();
    head = head.split("=")[0].trim();
    head = head.replace(/\s*\/\s*/g, "/").replace(/\s+/g, " ").trim();
    if (isSizeJunk(raw) && !SIZE_LABEL.test(head) && !SIZE_NUMERIC.test(head)) return "";
    if (head.indexOf("/") !== -1) {
      var parts = head.split("/").map(mapSizeToken);
      if (parts[0] && parts[1]) return parts[0] + "/" + parts[1];
    }
    var mapped = mapSizeToken(head);
    if (mapped) return mapped;
    if (SIZE_NUMERIC.test(head)) return head;
    if (/^(one\s*size|os|osfa)$/i.test(head)) return "One Size";
    return "";
  }
  function productSku(prod, variant) {
    if (variant && variant.sku) return variant.sku;
    var best = "";
    (prod.variants || []).forEach(function (item) {
      if (!item.sku) return;
      if (!best || String(item.sku).length < best.length) best = item.sku;
    });
    return best;
  }
  function displayOption(label, value) {
    return /size/i.test(label || "") ? canonicalSize(value) : String(value == null ? "" : value);
  }

  /* Quick view */
  var quickModal = qs("[data-quick-modal]");
  var modalBackdrop = qs("[data-modal-backdrop]");
  function closeQuick() {
    if (quickModal) quickModal.hidden = true;
    if (modalBackdrop) modalBackdrop.hidden = true;
    document.body.style.overflow = "";
  }
  qsa("[data-close-quick]").forEach(function (el) { el.addEventListener("click", closeQuick); });

  document.addEventListener("click", function (event) {
    var trigger = event.target.closest("[data-quick-view]");
    if (!trigger) return;
    event.preventDefault();
    var handle = trigger.getAttribute("data-quick-view");
    fetchJSON("/products/" + handle + ".js").then(function (prod) {
      var body = qs("[data-quick-body]");
      if (!body) return;
      prod = rematerializeProduct(prod);
      var optionsHtml = "";
      var picked = [];
      (prod.options || []).forEach(function (option, index) {
        var label = optionLabel(option);
        if (!label || label === "Title") return;
        var values = [];
        (prod.variants || []).forEach(function (variant) {
          var value = (variant.options || [])[index];
          if (value && values.indexOf(value) === -1) values.push(value);
        });
        if (!values.length) return;
        if (/plate/i.test(label)) {
          values.sort(function (a, b) {
            if (/^none$/i.test(a)) return -1;
            if (/^none$/i.test(b)) return 1;
            return a.localeCompare(b);
          });
        }
        var addon = isAddonLabel(label, values) || /plate/i.test(label);
        var noneAt = -1;
        values.forEach(function (value, valueIndex) {
          if (noneAt === -1 && isNoneValue(value)) noneAt = valueIndex;
        });
        var checkedAt = addon && noneAt !== -1 ? noneAt : 0;
        picked[index] = values[checkedAt];
        var isColor = /colou?r/i.test(label);
        var isPlate = /plate/i.test(label);
        optionsHtml += '<div class="option-label">' + escapeHtml(label) + '</div><div class="option-values' + (isColor ? " option-values--color" : "") + '" data-option-index="' + index + '" data-option-name="' + escapeHtml(label) + '"' + (isPlate ? ' data-plate-group="true"' : "") + ">";
        values.forEach(function (value, valueIndex) {
          var swatch = isColor ? '<i style="--swatch: ' + swatchBackground(value) + '"></i>' : "";
          var on = valueIndex === checkedAt;
          var shown = isPlate ? displayPlateLabel(value) : (/size/i.test(label) ? (canonicalSize(value) || value) : value);
          optionsHtml += '<label class="' + (isColor ? "swatch " : "") + (on ? "is-selected" : "") + '"><input type="radio" name="quick-option-' + index + '" value="' + escapeHtml(value) + '"' + (on ? " checked" : "") + ' data-option-input>' + swatch + '<span>' + escapeHtml(shown) + "</span></label>";
        });
        optionsHtml += "</div>";
        if (isPlate) {
          optionsHtml += '<p class="addon-note" data-addon-note>Choose None if you do not want a customized name plate.</p>';
          optionsHtml += '<div data-plate-fields hidden>' +
            '<div class="field"><label>Name for Plate (Only if $40 Option Added)</label><input class="input" type="text" name="properties[Name for Plate (Only if $40 Option Added)]"></div>' +
            '<div class="field"><label>Race Number (Only if Custom Option is Added)</label><input class="input" type="text" name="properties[Race Number (Only if Custom Option is Added)]"></div>' +
            "</div>";
        }
      });
      var letterSpan = "";
      (Array.isArray(prod.tags) ? prod.tags : String(prod.tags || "").split(",")).forEach(function (tag) {
        tag = String(tag || "").trim();
        if (tag.indexOf("letter-choice:") === 0) letterSpan = tag.slice(13);
      });
      if (letterSpan) {
        var letters = letterSpan === "A-V" ? "ABCDEFGHIJKLMNOPQRSTUV".split("") : letterSpan === "A-R" ? "ABCDEFGHIJKLMNOPQR".split("") : letterSpan.split(",");
        optionsHtml += '<div class="field"><label for="QuickDesignLetter">Design letter</label><select class="input" id="QuickDesignLetter" name="properties[Design Letter]" data-letter-choice><option value="">Select a letter</option>';
        letters.forEach(function (letter) {
          optionsHtml += '<option value="' + letter + '">' + letter + "</option>";
        });
        optionsHtml += "</select></div>";
      }
      var variant = (prod.variants || []).filter(function (item) {
        return (item.options || []).every(function (opt, i) { return picked[i] == null || opt === picked[i]; });
      }).sort(function (a, b) {
        if (a.available !== b.available) return a.available ? -1 : 1;
        return a.price - b.price;
      })[0] || (prod.variants || [])[0];
      if (!variant) return;
      var sku = productSku(prod, variant);
      var image = prod.featured_image || "";
      if (image && typeof image === "object") image = image.src || image.url || "";
      body.innerHTML =
        '<div class="quick-grid"><div><img src="' + escapeHtml(image) + '" alt=""></div><div>' +
        "<h3>" + escapeHtml(prod.title) + "</h3>" +
        '<div class="price" data-product-price>Now: ' + formatMoney(variant.price) + "</div>" +
        (sku ? '<p class="sku" data-sku>SKU: ' + escapeHtml(sku) + "</p>" : '<p class="sku" data-sku></p>') +
        '<form data-product-form><input type="hidden" name="id" value="' + variant.id + '" data-variant-id>' +
        optionsHtml +
        '<div class="qty-row"><label for="quick-qty">Qty</label><input class="input" id="quick-qty" name="quantity" type="number" min="1" value="1"></div>' +
        '<p class="form-errors" data-product-error hidden></p>' +
        '<button class="btn btn--full" type="submit" data-add-button>' + (variant.available ? "Add to Cart" : "Out of Stock") + "</button>" +
        '<a class="btn btn--dark btn--full" href="/checkout" style="margin-top:8px;">Checkout</a>' +
        '<p style="margin-top:10px"><a href="' + escapeHtml(prod.url) + '">View full details</a></p>' +
        "</form></div></div>";
      body.dataset.product = JSON.stringify(prod);
      if (quickModal) quickModal.hidden = false;
      if (modalBackdrop) modalBackdrop.hidden = false;
      document.body.style.overflow = "hidden";

      var qForm = qs("[data-product-form]", body);
      function sync() {
        var options = [];
        qsa("[data-option-index]", qForm).forEach(function (group) {
          var checked = qs("input:checked", group);
          options[Number(group.getAttribute("data-option-index"))] = checked ? checked.value : "";
          qsa("label", group).forEach(function (label) {
            var input = qs("input", label);
            label.classList.toggle("is-selected", !!(input && input.checked));
          });
        });
        syncPlateTextFields(qForm);
        var matches = (prod.variants || []).filter(function (item) {
          return (item.options || []).every(function (opt, i) { return options[i] == null || options[i] === "" || opt === options[i]; });
        }).sort(function (a, b) { return a.price - b.price; });
        var match = matches[0];
        if (!match) return;
        qs("[data-variant-id]", qForm).value = match.id;
        qs("[data-product-price]", body).textContent = "Now: " + formatMoney(match.price);
        var skuEl = qs("[data-sku]", body);
        var nextSku = productSku(prod, match);
        if (skuEl) skuEl.textContent = nextSku ? "SKU: " + nextSku : "";
        var btn = qs("[data-add-button]", qForm);
        btn.disabled = !match.available;
        btn.textContent = match.available ? "Add to Cart" : "Out of Stock";
        if (match.featured_image && match.featured_image.src) qs("img", body).src = match.featured_image.src;
      }
      qForm.addEventListener("change", sync);
    }).catch(function () { window.location.href = "/products/" + handle; });
  });

  /* Wishlist */
  var WISH_KEY = "jettribe_wishlist";
  function readWish() {
    try { return JSON.parse(localStorage.getItem(WISH_KEY) || "[]"); }
    catch (e) { return []; }
  }
  function writeWish(list) {
    localStorage.setItem(WISH_KEY, JSON.stringify(list));
    qsa("[data-wish-count]").forEach(function (el) { el.textContent = list.length ? "(" + list.length + ")" : ""; });
  }
  writeWish(readWish());

  document.addEventListener("click", function (event) {
    var wishBtn = event.target.closest("[data-wish-toggle]");
    if (!wishBtn) return;
    event.preventDefault();
    var handle = wishBtn.getAttribute("data-wish-toggle");
    var list = readWish();
    var idx = list.indexOf(handle);
    if (idx === -1) list.push(handle);
    else list.splice(idx, 1);
    writeWish(list);
    wishBtn.textContent = idx === -1 ? "Saved" : "Wishlist";
  });

  var wishDrawer = qs("[data-wish-drawer]");
  var wishBackdrop = qs("[data-wish-backdrop]");
  function closeWish() {
    if (wishDrawer) wishDrawer.hidden = true;
    if (wishBackdrop) wishBackdrop.hidden = true;
    document.body.style.overflow = "";
  }
  qsa("[data-close-wish]").forEach(function (el) { el.addEventListener("click", closeWish); });
  qsa("[data-open-wish]").forEach(function (el) {
    el.addEventListener("click", function (event) {
      event.preventDefault();
      var list = readWish();
      var body = qs("[data-wish-body]");
      if (!list.length) {
        body.innerHTML = "<p>Your wishlist is empty. Save gear from any product card.</p>";
      } else {
        body.innerHTML = "<p>Loading saved gear…</p>";
        Promise.all(list.map(function (handle) {
          return fetchJSON("/products/" + handle + ".js").catch(function () { return null; });
        })).then(function (products) {
          body.innerHTML = products.filter(Boolean).map(function (prod) {
            return '<article class="drawer-line"><a href="' + prod.url + '"><img src="' + (prod.featured_image || "") + '" alt=""></a><div><a href="' + prod.url + '">' + prod.title + '</a><div class="price">' + formatMoney(prod.price) + '</div><button type="button" class="remove-link" data-wish-toggle="' + prod.handle + '">Remove</button></div></article>';
          }).join("") || "<p>Your wishlist is empty.</p>";
        });
      }
      if (wishDrawer) wishDrawer.hidden = false;
      if (wishBackdrop) wishBackdrop.hidden = false;
    });
  });

  var COMPARE_KEY = "jt_compare";
  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }
  function readCompare() {
    try { return JSON.parse(localStorage.getItem(COMPARE_KEY) || "[]"); }
    catch (e) { return []; }
  }
  function writeCompare(list) {
    localStorage.setItem(COMPARE_KEY, JSON.stringify(list));
    paintCompare();
  }
  function paintCompare() {
    var bar = qs("[data-compare-bar]");
    if (!bar) return;
    var list = readCompare();
    bar.hidden = list.length === 0;
    document.body.classList.toggle("has-compare", list.length > 0);
    var label = qs("[data-compare-label]");
    if (label) label.textContent = list.length + " of 4 selected";
    var thumbs = qs("[data-compare-thumbs]");
    if (thumbs) {
      thumbs.innerHTML = list.map(function (item) {
        return '<button type="button" class="compare-thumb" data-compare-remove="' + esc(item.id) + '"><img src="' + esc(item.img) + '" alt=""><span>' + esc(item.title) + "</span></button>";
      }).join("");
    }
    var ids = list.map(function (item) { return String(item.id); });
    qsa("input[data-compare-add]").forEach(function (input) {
      input.checked = ids.indexOf(String(input.getAttribute("data-id"))) !== -1;
    });
    qsa("[data-compare-button]").forEach(function (btn) {
      var on = ids.indexOf(String(btn.getAttribute("data-id"))) !== -1;
      btn.textContent = on ? "Added to compare" : "Compare";
    });
  }
  function itemFrom(el) {
    return {
      id: el.getAttribute("data-id"),
      title: el.getAttribute("data-title") || "",
      price: el.getAttribute("data-price") || "0",
      img: el.getAttribute("data-img") || "",
      url: el.getAttribute("data-url") || "#"
    };
  }
  document.addEventListener("change", function (event) {
    var input = event.target.closest && event.target.closest("input[data-compare-add]");
    if (!input) return;
    var id = input.getAttribute("data-id");
    var list = readCompare().filter(function (item) { return String(item.id) !== String(id); });
    if (input.checked) {
      if (list.length >= 4) {
        input.checked = false;
        var bar = qs("[data-compare-bar]");
        if (bar) bar.hidden = false;
        var label = qs("[data-compare-label]");
        if (label) label.textContent = "Compare up to 4 products";
        return;
      }
      list.push(itemFrom(input));
    }
    writeCompare(list);
  });
  document.addEventListener("click", function (event) {
    var button = event.target.closest && event.target.closest("[data-compare-button]");
    if (button) {
      event.preventDefault();
      var id = button.getAttribute("data-id");
      var list = readCompare();
      if (list.some(function (item) { return String(item.id) === String(id); })) {
        writeCompare(list.filter(function (item) { return String(item.id) !== String(id); }));
      } else if (list.length >= 4) {
        var full = qs("[data-compare-bar]");
        if (full) full.hidden = false;
        var note = qs("[data-compare-label]");
        if (note) note.textContent = "Compare up to 4 products";
      } else {
        list.push(itemFrom(button));
        writeCompare(list);
      }
      return;
    }
    var remove = event.target.closest && event.target.closest("[data-compare-remove]");
    if (remove) {
      var rid = remove.getAttribute("data-compare-remove");
      writeCompare(readCompare().filter(function (item) { return String(item.id) !== String(rid); }));
      var modal = qs("[data-compare-modal]");
      if (modal && !modal.hidden && readCompare().length < 2) {
        modal.hidden = true;
        document.body.style.overflow = "";
      } else if (modal && !modal.hidden) {
        openCompare();
      }
      return;
    }
    if (event.target.closest && event.target.closest("[data-compare-clear]")) {
      writeCompare([]);
      var openModal = qs("[data-compare-modal]");
      if (openModal) openModal.hidden = true;
      document.body.style.overflow = "";
      return;
    }
    if (event.target.closest && event.target.closest("[data-compare-open]")) {
      openCompare();
      return;
    }
    if (event.target.closest && event.target.closest("[data-compare-close]")) {
      var closeModal = qs("[data-compare-modal]");
      if (closeModal) closeModal.hidden = true;
      document.body.style.overflow = "";
      return;
    }
    if (event.target.matches && event.target.matches("[data-compare-modal]")) {
      event.target.hidden = true;
      document.body.style.overflow = "";
    }
  });
  function openCompare() {
    var picked = readCompare();
    var label = qs("[data-compare-label]");
    if (picked.length < 2) {
      if (label) label.textContent = "Select at least 2 products";
      return;
    }
    var grid = qs("[data-compare-grid]");
    if (!grid) return;
    grid.innerHTML = picked.map(function (item) {
      return '<article class="compare-col"><a href="' + esc(item.url) + '"><img src="' + esc(item.img) + '" alt=""></a><h3><a href="' + esc(item.url) + '">' + esc(item.title) + '</a></h3><p class="price">Now: ' + formatMoney(Number(item.price) || 0) + '</p><a class="btn" href="' + esc(item.url) + '">View</a><button type="button" class="remove-link" data-compare-remove="' + esc(item.id) + '">Remove</button></article>';
    }).join("");
    qs("[data-compare-modal]").hidden = false;
    document.body.style.overflow = "hidden";
  }
  paintCompare();

  qsa("[data-price-range]").forEach(function (box) {
    var minR = qs('[data-range="min"]', box);
    var maxR = qs('[data-range="max"]', box);
    if (!minR || !maxR) return;
    var minN = qs("[data-price-min]", box);
    var maxN = qs("[data-price-max]", box);
    var minL = qs("[data-price-min-label]", box);
    var maxL = qs("[data-price-max-label]", box);
    function sync(which) {
      var a = Number(minR.value);
      var b = Number(maxR.value);
      if (a > b) {
        if (which === "min") { a = b; minR.value = String(a); }
        else { b = a; maxR.value = String(b); }
      }
      if (minN) minN.value = String(a);
      if (maxN) maxN.value = String(b);
      if (minL) minL.textContent = formatMoney(a * 100);
      if (maxL) maxL.textContent = formatMoney(b * 100);
    }
    minR.addEventListener("input", function () { sync("min"); });
    maxR.addEventListener("input", function () { sync("max"); });
    minR.addEventListener("change", function () { box.submit(); });
    maxR.addEventListener("change", function () { box.submit(); });
  });

  var colorWords = [
    ["Black", "#161616", /\bblack\b/i],
    ["Blue", "#1d4ed8", /\bblue\b/i],
    ["Red", "#e53d42", /\bred\b/i],
    ["Teal", "#0f766e", /\bteal\b/i],
    ["Green", "#2f8f4e", /\bgreen\b/i],
    ["Pink", "#e56aa0", /\b(pink|magenta|fuchsia)\b/i],
    ["Grey", "#8a8a8a", /\bgr[ae]y\b/i],
    ["Aqua", "#3ec6d4", /\baqua\b/i],
    ["Orange", "#f97316", /\borange\b/i],
    ["White", "#f7f7f7", /\bwhite\b/i],
    ["Purple", "#7c3aed", /\bpurple\b/i],
    ["Yellow", "#eab308", /\byellow\b/i],
    ["Navy", "#1e3a8a", /\bnavy\b/i]
  ];
  function titleColors(text) {
    return colorWords.filter(function (row) { return row[2].test(text || ""); }).map(function (row) { return row[0]; });
  }
  var colorList = qs("[data-client-color-list]");
  var sizeList = qs("[data-client-size-list]");
  if (colorList || sizeList) {
    var cards = qsa(".product-grid .card");
    var colorCounts = {};
    var sizeCounts = {};
    cards.forEach(function (card) {
      var titleEl = qs(".card-title", card);
      titleColors(titleEl ? titleEl.textContent : "").forEach(function (name) {
        colorCounts[name] = (colorCounts[name] || 0) + 1;
      });
      (card.getAttribute("data-sizes") || "").split("|").filter(Boolean).forEach(function (size) {
        var key = canonicalSize(size);
        if (!key) return;
        sizeCounts[key] = (sizeCounts[key] || 0) + 1;
      });
    });
    var colorNames = Object.keys(colorCounts);
    var sizeNames = Object.keys(sizeCounts);
    if (colorList && colorNames.length) {
      colorList.innerHTML = colorNames.map(function (name) {
        var hex = "#c8c8c8";
        colorWords.forEach(function (row) { if (row[0] === name) hex = row[1]; });
        return '<button type="button" class="swatch" data-client-color="' + escapeHtml(name) + '" style="--swatch:' + hex + '"><i></i><span>' + escapeHtml(name) + "</span></button>";
      }).join("");
      var colorFacet = colorList.closest("[data-client-colors]");
      if (colorFacet) colorFacet.hidden = false;
    }
    if (sizeList && sizeNames.length) {
      sizeList.innerHTML = sizeNames.map(function (size) {
        return '<button type="button" class="size-chip" data-client-size="' + escapeHtml(size) + '">' + escapeHtml(size) + "</button>";
      }).join("");
      var sizeFacet = sizeList.closest("[data-client-sizes]");
      if (sizeFacet) sizeFacet.hidden = false;
    }
    function applyClientFacets() {
      var colors = qsa("[data-client-color].is-active").map(function (el) { return el.getAttribute("data-client-color"); });
      var sizes = qsa("[data-client-size].is-active").map(function (el) { return el.getAttribute("data-client-size"); });
      cards.forEach(function (card) {
        var titleEl = qs(".card-title", card);
        var hasColor = titleColors(titleEl ? titleEl.textContent : "");
        var hasSize = (card.getAttribute("data-sizes") || "").split("|").filter(Boolean).map(canonicalSize);
        var colorOk = !colors.length || colors.some(function (color) { return hasColor.indexOf(color) !== -1; });
        var sizeOk = !sizes.length || sizes.some(function (size) { return hasSize.indexOf(canonicalSize(size)) !== -1; });
        card.hidden = !(colorOk && sizeOk);
      });
    }
    qsa("[data-client-color], [data-client-size]").forEach(function (button) {
      button.addEventListener("click", function () {
        button.classList.toggle("is-active");
        applyClientFacets();
      });
    });
  }

  document.addEventListener("catalog:rendered", paintCompare);

  function menuHandle(href) {
    try {
      return new URL(href, window.location.origin).searchParams.get("jtcat") || "";
    } catch (err) {
      return "";
    }
  }
  function menuCount(data, handle) {
    if (!handle) return null;
    var cats = data.categories || {};
    var key = cats[handle] ? handle : "";
    if (!key) {
      var lower = handle.toLowerCase();
      Object.keys(cats).some(function (name) {
        if (name.toLowerCase() === lower) {
          key = name;
          return true;
        }
        return false;
      });
    }
    if (!key) return null;
    return (cats[key].products || []).length;
  }
  function hideEmptyMenu(data) {
    qsa(".mega-col").forEach(function (col) {
      var links = qsa("a[href*='jtcat=']", col);
      var stocked = false;
      var known = 0;
      links.forEach(function (link) {
        var count = menuCount(data, menuHandle(link.getAttribute("href")));
        if (count === null) stocked = true;
        else {
          known += 1;
          if (count > 0) stocked = true;
        }
      });
      if (known && !stocked) {
        col.hidden = true;
        return;
      }
      links.forEach(function (link) {
        var count = menuCount(data, menuHandle(link.getAttribute("href")));
        if (count !== 0) return;
        if (link.classList.contains("mega-head")) return;
        link.hidden = true;
      });
    });
    qsa("a[href*='jtcat=']").forEach(function (link) {
      if (link.closest(".site-nav")) return;
      if (link.closest(".mega-col")) return;
      if (link.parentElement && link.parentElement.classList.contains("has-sub")) return;
      if (menuCount(data, menuHandle(link.getAttribute("href"))) !== 0) return;
      var item = link.closest("li");
      if (item && qsa("a[href*='jtcat=']", item).length === 1 && !item.classList.contains("has-sub")) item.hidden = true;
      else link.hidden = true;
    });
  }
  /* Never hide menu links. Empty categories were remapped so every link opens products. */

  document.addEventListener("DOMContentLoaded", function () {
    var menu = document.getElementById("JettribeMenu");
    if (!menu) return;
    menu.style.display = "block";
    menu.style.visibility = "visible";
    menu.hidden = false;
    menu.removeAttribute("hidden");
  });

  function mountPayPalMessages(root) {
    var sdk = window.paypalMessages;
    if (!sdk || !sdk.Messages) return;
    qsa("[data-pp-message]", root || document).forEach(function (el) {
      var amount = el.getAttribute("data-pp-amount") || "";
      if (el.getAttribute("data-pp-mounted") === amount && el.childNodes.length) return;
      el.innerHTML = "";
      el.setAttribute("data-pp-mounted", amount);
      var props = {
        placement: el.getAttribute("data-pp-placement") || "product",
        style: {
          layout: "text",
          logo: { type: "inline", position: "left" },
          text: { color: "black", size: "12" }
        }
      };
      if (amount) props.amount = amount;
      sdk.Messages(props).render(el);
    });
  }
  document.addEventListener("paypal:ready", function () { mountPayPalMessages(); });
  mountPayPalMessages();

  /* Cart page quantity posts stay native. Gallery on cart is server rendered. */
  function reviewStars(count) {
    var n = Math.max(0, Math.min(5, Number(count) || 0));
    return "★★★★★".slice(0, n) + "☆☆☆☆☆".slice(0, 5 - n);
  }
  function paintReviews(root, list) {
    if (!root) return;
    var tab = qs('[data-tab="reviews"]');
    if (!list || !list.length) {
      root.innerHTML = "<p>No reviews for this product yet.</p>";
      if (tab) tab.textContent = "Reviews";
      return;
    }
    if (tab) tab.textContent = "Reviews (" + list.length + ")";
    var total = list.reduce(function (sum, review) { return sum + Number(review.rating || 0); }, 0);
    var html = '<p class="review-meta"><span class="review-stars" aria-hidden="true">' + reviewStars(Math.round(total / list.length)) + "</span> " + list.length + (list.length === 1 ? " review" : " reviews") + '</p><div class="review-list">';
    list.forEach(function (review) {
      html += '<article class="review-card"><div class="review-stars" aria-label="' + esc(review.rating || 0) + ' out of 5">' + reviewStars(review.rating) + "</div>";
      if (review.title) html += "<h3>" + esc(review.title) + "</h3>";
      html += '<p class="review-meta">' + esc(review.author || "Customer") + (review.date ? " · " + esc(review.date) : "") + "</p>";
      html += "<p>" + esc(review.body || "") + "</p>";
      if (review.image) html += '<p><img src="' + esc(review.image) + '" alt="' + esc(review.title || "Customer photo") + '" width="280" loading="lazy"></p>';
      html += "</article>";
    });
    root.innerHTML = html + "</div>";
    var old = qs("script[data-review-schema]");
    if (old) old.remove();
    var data = {
      "@context": "https://schema.org",
      "@type": "Product",
      "name": (qs(".product-title") || {}).textContent || "",
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": (total / list.length).toFixed(1),
        "reviewCount": String(list.length)
      },
      "review": list.slice(0, 8).map(function (review) {
        return {
          "@type": "Review",
          "author": { "@type": "Person", "name": review.author || "Customer" },
          "datePublished": review.date || "",
          "name": review.title || "",
          "reviewBody": review.body || "",
          "reviewRating": { "@type": "Rating", "ratingValue": String(review.rating || 0), "bestRating": "5" }
        };
      })
    };
    var script = document.createElement("script");
    script.type = "application/ld+json";
    script.setAttribute("data-review-schema", "");
    script.textContent = JSON.stringify(data);
    document.head.appendChild(script);
  }
  function demoteExtraHeadings() {
    qsa(".rte h1, .product-lower h1").forEach(function (heading) {
      if (heading.classList.contains("product-title")) return;
      var next = document.createElement("h2");
      next.innerHTML = heading.innerHTML;
      next.className = heading.className;
      heading.replaceWith(next);
    });
  }
  demoteExtraHeadings();
  document.addEventListener("catalog:rendered", demoteExtraHeadings);
  var reviewRoot = qs("[data-product-reviews]");
  if (reviewRoot && window.Jettribe && Jettribe.reviewsUrl) {
    fetch(Jettribe.reviewsUrl, { headers: { Accept: "application/json" } })
      .then(function (res) { return res.ok ? res.json() : {}; })
      .then(function (data) {
        paintReviews(reviewRoot, data[reviewRoot.getAttribute("data-product-reviews")] || []);
      })
      .catch(function () {});
  }

  qsa("[data-country-select]").forEach(function (country) {
    var province = qs("#" + country.getAttribute("data-province"));
    if (!province || !window.Shopify || !Shopify.CountryProvinceSelector) return;
    new Shopify.CountryProvinceSelector(country.id, province.id, {
      hideElement: country.getAttribute("data-province-container")
    });
  });
})();
